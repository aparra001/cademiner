# Docker Hub custom hooks

## pre_build

Clone and update submodules needed by the project.